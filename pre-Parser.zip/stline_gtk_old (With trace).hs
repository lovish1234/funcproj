{-# LANGUAGE PatternGuards #-}
-- | Simple picture drawing application. 
--   Like MSPaint, but you can only draw straight lines.
import Graphics.Gloss.Interface.Pure.Game as Gloss
import Graphics.Gloss
import Data.Maybe (maybe)
import Debug.Trace
import qualified Graphics.UI.Gtk as Gtk
import Graphics.UI.Gtk.Builder
import Control.Concurrent
import Control.Concurrent.STM
import Control.Concurrent.STM.TVar
import Control.Monad.IO.Class


main
 = do   let state = stateM $ State Nothing []
        Gtk.initGUI
        builder <- builderNew
        builderAddFromFile builder "gui_window.glade"
        window   <- builderGetObject builder Gtk.castToWindow "window1"
        Gtk.onDestroy window Gtk.mainQuit

        ------------- Mutable variable ------------
        global_var <- newTVarIO 0
    ------------------------------------------------------------------------
        r1_b1 <- builderGetObject builder Gtk.castToButton "r1_button1"
        Gtk.onClicked r1_b1 $ do
            -- call 'pencil'
            putStrLn "pencil"
            atomically $ transfer 11 global_var
    ------------------------------------------------------------------------
        r1_b2 <- builderGetObject builder Gtk.castToButton "r1_button2"
        Gtk.onClicked r1_b2 $ do
            -- call 'straight line'
            putStrLn "straight line"
            atomically $ transfer 12 global_var
    ------------------------------------------------------------------------
        forkIO $ do
            Gtk.widgetShowAll window
            Gtk.mainGUI
        return ()
        
        
        play    (InWindow "Draw" (600, 600) (0,0))
                white 100 state
                makePicture (handleEvent' global_var) stepWorld


-- | The game state.
data State      
        = State (Maybe Path)    -- The current line being drawn.
                [Picture]       -- All the lines drawn previously.
                deriving Show

-- | Convert our state to a picture.
makePicture :: STM State -> STM Picture
--makePicture (State m xs)
  --      = Pictures (maybe xs (\x -> Line x : xs) m)
makePicture state
          = do
                retrieved_state <- state
                case retrieved_state
                    of (State m xs)  -> return $ Pictures (maybe xs (\x -> Line x :xs) m)

-- | Handle mouse click and motion events.
handleEvent :: Event -> State -> Integer -> State
handleEvent event state intvar
        -- If the mouse has moved, then extend the current line.
        | EventMotion (x, y)    <- event
        , State (Just [a,_]) ss    <- state
        = if (intvar == 12)
            then 
                State (Just [a,(x, y)]) ss 
            else state

        -- Start drawing a new line.
        | EventKey (MouseButton LeftButton) Down _ pt@(x,y) <- event
        , State Nothing ss       <- state
        = if (intvar == 12)
            then
                trace ( "LeftButton - down_" ++ (show state) ++ "_" ++ (show y) ) ( State (Just [(x,y),(x,y)]) ss )
            else
                trace (show intvar) state

        -- Finish drawing a line, and add it to the picture.
        | EventKey (MouseButton LeftButton) Up _ pt@(x,y)      <- event
        , State (Just [a,_]) ss    <- state
        = if (intvar == 12)
            then
                trace ( "LeftButton - up_" ++ (show state) ++ "_" ++ (show y) ) ( State Nothing ((Line [a,(x,y)]):ss) )
            else
                trace (show intvar) state

        | otherwise
        = state

handleEvent' :: TVar Integer -> Event -> STM State -> STM State
handleEvent' global_var event stateM
        = do
            state <- stateM
            intvar <- readTVar global_var
            trace ((show intvar) ++ "**") (return $ handleEvent event state intvar)

stepWorld :: Float -> STM State -> STM State
stepWorld _ = id

stateM :: State -> STM (State)
stateM = return

transfer :: Integer -> TVar Integer -> STM ()
transfer a b = do
    c <- readTVar b
    writeTVar b (a)
