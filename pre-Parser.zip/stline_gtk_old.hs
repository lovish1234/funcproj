{-# LANGUAGE PatternGuards #-}
-- | Simple picture drawing application. 
--   Like MSPaint, but you can only draw straight lines.
import Graphics.Gloss.Interface.Pure.Game as Gloss
import Graphics.Gloss
import Data.Maybe (maybe)
import Debug.Trace
import qualified Graphics.UI.Gtk as Gtk
import Graphics.UI.Gtk.Builder
import Control.Concurrent
import Control.Concurrent.STM
import Control.Concurrent.STM.TVar
import Control.Monad.IO.Class


main
 = do   let state = stateM $ Phi [Translate 10 10 (Circle 5)]


        ------------- Mutable variable ------------
        global_var <- newTVarIO 0

        tid <- forkIO $ do
                Gtk.initGUI
                builder <- builderNew
                builderAddFromFile builder "gui_window.glade"
                window   <- builderGetObject builder Gtk.castToWindow "window1"
                Gtk.onDestroy window Gtk.mainQuit
            ------------------------------------------------------------------------
                r1_b1 <- builderGetObject builder Gtk.castToButton "r1_button1"
                Gtk.onClicked r1_b1 $ do
                    -- call 'pencil'
                    putStrLn "pencil"
                    transfer 11 global_var
            ------------------------------------------------------------------------
                r1_b2 <- builderGetObject builder Gtk.castToButton "r1_button2"
                Gtk.onClicked r1_b2 $ do
                    -- call 'straight line'
                    putStrLn "straight line"
                    transfer 12 global_var
            ------------------------------------------------------------------------
                r2_b1 <- builderGetObject builder Gtk.castToButton "r2_button1"
                Gtk.onClicked r2_b1 $ do
                    -- call 'circle'
                    putStrLn "circle"
                    transfer 13 global_var
            ------------------------------------------------------------------------
                Gtk.widgetShowAll window
                Gtk.mainGUI
        return ()
        
        global_tid <- newTVarIO tid
        
        play    (InWindow "Draw" (600, 600) (0,0))
                white 100 state
                makePicture (handleEvent' global_var global_tid) stepWorld


-- | The game state.
data State      
        = Phi [Picture]
        | MyLine (Maybe Path) [Picture]
        | MyPencil (Maybe Path) [Picture]
        | MyCircle (Maybe (Float,Float,Float)) [Picture]
        deriving Show

-- | Convert our state to a picture.
makePicture :: IO State -> IO Picture
--makePicture (State m xs)
  --      = Pictures (maybe xs (\x -> Line x : xs) m)
makePicture state
          = do
                retrieved_state <- state
                case retrieved_state of 
                    (MyLine m xs)   -> return $ Pictures (maybe xs (\x -> Line x :xs) m)
                    (MyPencil m xs) -> return $ Pictures (maybe xs (\x -> Line x :xs) m)
                    Phi x           -> return $ Pictures x
                    (MyCircle m xs) -> return $ Pictures (maybe xs (\(a,b,c) -> (Translate a b (Circle c)) : xs) m)

-- | Handle mouse click and motion events.
handleEvent :: Event -> State -> Integer -> State
handleEvent event state 12
        -- If the mouse has moved, then extend the current line.
        | EventMotion (x, y)    <- event
        , MyLine (Just [a,_]) ss    <- state
        = MyLine (Just [a,(x, y)]) ss 

        -- Start drawing a new line.
        | EventKey (MouseButton LeftButton) Down _ pt@(x,y) <- event
        , Phi ss       <- state
        = MyLine (Just [(x,y),(x,y)]) ss 

        -- Finish drawing a line, and add it to the picture.
        | EventKey (MouseButton LeftButton) Up _ pt@(x,y)      <- event
        , MyLine (Just [a,_]) ss    <- state
        -- = trace ("custom state :" ++ (show $ Phi ((Line [a,(x,y)]):ss))) (Phi ((Line [a,(x,y)]):ss))
        = Phi ((Line [a,(x,y)]):ss)

		| EventMotion (x, y)    <- event
		, Phi ss       <- state
		= state
	
        | otherwise
        = state

handleEvent event state 11
        -- If the mouse has moved, then extend the current line.
        | EventMotion (x, y)    <- event
        , MyPencil (Just ps) ss    <- state
        = MyPencil (Just ((x, y):ps)) ss 

        -- Start drawing a new line.
        | EventKey (MouseButton LeftButton) Down _ pt@(x,y) <- event
        , Phi ss       <- state
        = MyPencil (Just [pt])  ss

        -- Finish drawing a line, and add it to the picture.
        | EventKey (MouseButton LeftButton) Up _ pt@(x,y)      <- event
        , MyPencil (Just ps) ss    <- state
        = Phi ( (Line (pt:ps) ) : ss) 

        | otherwise
        =  state

handleEvent event state 13
        -- If the mouse has moved, then update the radius of the circle.
        | EventMotion (x, y)    <- event
        , MyCircle (Just (a,b,_)) ss    <- state
        = MyCircle (Just (a,b,(sqrt((a-x)*(a-x) + (b-y)*(b-y))))) ss

        -- Start drawing a new circle.
        | EventKey (MouseButton LeftButton) Down _ pt@(x,y) <- event
        , Phi ss       <- state
        = MyCircle (Just (x,y,0.0)) ss

        -- Finish drawing a circle, and add it to the picture.
        | EventKey (MouseButton LeftButton) Up _ pt@(x,y)      <- event
        , MyCircle (Just (a,b,_)) ss    <- state
        = Phi ((Translate a b (Circle (sqrt((a-x)*(a-x) + (b-y)*(b-y))))):ss)

        | otherwise
        = state

handleEvent event state _
        = state

handleEvent' :: TVar Integer -> TVar ThreadId -> Event -> IO State -> IO State
handleEvent' global_var global_tid event stateM
        = do
            state <- stateM
            intvar <- readTVarIO global_var
            -- atomically $ writeTVar global_var (intvar+1)
            tid <- readTVarIO global_tid
            -- putStrLn $ "STATE:"++ (show state)
            -- threadDelay 10000
            return $ handleEvent event state intvar

stepWorld :: Float -> IO State -> IO State
stepWorld _ = id

stateM :: State -> IO (State)
stateM = return

transfer :: Integer -> TVar Integer -> IO ()
transfer a b = do
    c <- readTVarIO b
    atomically $ writeTVar b (a)
