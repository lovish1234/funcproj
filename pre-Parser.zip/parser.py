f=open("Arambol.hs")
ans=[]

def func(s):
	if s in ["(",")"]:
		return False
	else:
		return True	

for line in f:
	typer = ""
	#~ print line
	l=filter(func,line)
	#~ print l
	l=filter(func,l.split())
	#~ print l
	if "Translate" in l:
		x = str(eval(l[l.index("Translate")+1]))
		y = str(eval(l[l.index("Translate")+2]))
		
	else:
		"FATAL!!"
		break
	if "Circle" in l:
		
		rad = eval(l[l.index("Circle")+1])
		if "Scale" in l:
			typer = "Ellipse"			
			b = str(rad * eval(l[l.index("Scale")+1]))			
			deg = str(eval(l[l.index("Rotate")+1]))
			ans.append(typer+" ("+x+","+y+","+str(rad)+","+deg+","+b+")\n")
		else:
			typer="Circle"
			ans.append(typer+" ("+x+","+y+","+str(rad)+")\n")
	if "Line" in l:
		if "Rotate" in l:
			#~ print "here"
			deg = str(eval(l[l.index("Rotate")+1]))
			pointlist = (eval(l[l.index("Line")+1]))
			#~ print len(pointlist)
			if len(pointlist) > 10:
				typer = "Line"
				ans.append(typer+" ("+x+","+y+","+str(pointlist)+")\n")
			else:
				
				if max(abs(pointlist[0]-pointlist[2]),abs(pointlist[1]-pointlist[3])) == (max(abs(pointlist[2]-pointlist[4]),abs(pointlist[3]-pointlist[5]))):
					typer = "Square"
					ans.append(typer+" ("+x+","+y+","+deg+","+str(max(abs(pointlist[0]-pointlist[2]),abs(pointlist[1]-pointlist[3])))+")\n")
				else:
					typer = "Rectangle"		
					ans.append(typer+" ("+x+","+y+","+deg+","+str(max(abs(pointlist[0]-pointlist[2]),abs(pointlist[1]-pointlist[3])))+","+str(max(abs(pointlist[2]-pointlist[4]),abs(pointlist[3]-pointlist[5])))+")\n")
f=open("pictoUser.txt","w")
for i in ans:
	f.write(i)
